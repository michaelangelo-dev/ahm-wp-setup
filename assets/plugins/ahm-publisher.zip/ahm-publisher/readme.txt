=== AHM Publisher ===

Lets AHM Brain publish blog posts to this WordPress site securely, using an API
key instead of a login. Because the key is sent in the request body (not the
Authorization header), it keeps working even when a security plugin or the host
blocks the WordPress REST API / Application Passwords.

INSTALL
1. WordPress admin: Plugins -> Add New -> Upload Plugin -> choose ahm-publisher.zip -> Install -> Activate.
2. Go to Settings -> AHM Publisher.
3. Copy the Site address and API key into AHM Brain (client's WordPress tab, "AHM Publisher plugin" method).

No settings to configure. Regenerate the key anytime from the same screen.
