<?php
/**
 * Plugin Name: AHM Publisher
 * Description: Lets AHM Brain publish blog posts to this site securely via an API key. No login/Authorization header needed, so it works even behind security plugins and firewalls.
 * Version: 1.1.0
 * Author: Allied Health Media
 */

if (!defined('ABSPATH')) exit;

define('AHM_PUB_OPT', 'ahm_publisher_api_key');
define('AHM_PUB_VER', '1.1.0');

// Generate an API key when the plugin is activated.
register_activation_hook(__FILE__, function () {
  if (!get_option(AHM_PUB_OPT)) {
    update_option(AHM_PUB_OPT, wp_generate_password(40, false, false));
  }
});

// Settings screen: Settings -> AHM Publisher (shows the values to paste into AHM Brain).
add_action('admin_menu', function () {
  add_options_page('AHM Publisher', 'AHM Publisher', 'manage_options', 'ahm-publisher', 'ahm_pub_settings_page');
});

function ahm_pub_settings_page() {
  if (!current_user_can('manage_options')) return;
  if (isset($_POST['ahm_regen']) && check_admin_referer('ahm_pub_regen')) {
    update_option(AHM_PUB_OPT, wp_generate_password(40, false, false));
    echo '<div class="updated notice"><p>New API key generated. Update it in AHM Brain.</p></div>';
  }
  if (!get_option(AHM_PUB_OPT)) update_option(AHM_PUB_OPT, wp_generate_password(40, false, false));
  $key = get_option(AHM_PUB_OPT);
  echo '<div class="wrap"><h1>AHM Publisher</h1>';
  echo '<p>Paste these two values into the <strong>WordPress</strong> tab for this client in AHM Brain, choosing the <em>AHM Publisher plugin</em> method.</p>';
  echo '<table class="form-table">';
  echo '<tr><th scope="row">Site address</th><td><code>' . esc_html(home_url()) . '</code></td></tr>';
  echo '<tr><th scope="row">API key</th><td><input type="text" readonly value="' . esc_attr($key) . '" style="width:440px;font-family:monospace" onclick="this.select()"></td></tr>';
  echo '</table>';
  echo '<form method="post" style="margin-top:8px">';
  wp_nonce_field('ahm_pub_regen');
  echo '<button class="button" name="ahm_regen" value="1" onclick="return confirm(\'Generate a new key? You will need to update it in AHM Brain.\')">Regenerate API key</button>';
  echo '</form></div>';
}

// Public endpoints via admin-ajax (available even when the REST API is locked down).
add_action('wp_ajax_nopriv_ahm_ping', 'ahm_pub_ping');
add_action('wp_ajax_ahm_ping', 'ahm_pub_ping');
add_action('wp_ajax_nopriv_ahm_publish', 'ahm_pub_publish');
add_action('wp_ajax_ahm_publish', 'ahm_pub_publish');

function ahm_pub_auth() {
  $stored = get_option(AHM_PUB_OPT);
  $given = isset($_POST['api_key']) ? (string) $_POST['api_key'] : '';
  if (!$stored || !$given || !hash_equals($stored, $given)) {
    wp_send_json(array('ok' => false, 'error' => 'Invalid API key.'), 401);
  }
}

function ahm_pub_ping() {
  ahm_pub_auth();
  wp_send_json(array('ok' => true, 'name' => get_bloginfo('name'), 'site' => home_url(), 'version' => AHM_PUB_VER));
}

function ahm_pub_admin_author() {
  $admins = get_users(array('role' => 'administrator', 'number' => 1, 'fields' => 'ID'));
  return !empty($admins) ? intval($admins[0]) : 0;
}

function ahm_pub_publish() {
  ahm_pub_auth();

  $title   = isset($_POST['title'])   ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
  $content = isset($_POST['content']) ? wp_kses_post(wp_unslash($_POST['content'])) : '';
  $status  = (isset($_POST['status']) && $_POST['status'] === 'publish') ? 'publish' : 'draft';
  $slug    = isset($_POST['slug'])    ? sanitize_title(wp_unslash($_POST['slug'])) : '';
  $excerpt = isset($_POST['excerpt']) ? sanitize_textarea_field(wp_unslash($_POST['excerpt'])) : '';
  $post_id = isset($_POST['wp_post_id']) ? intval($_POST['wp_post_id']) : 0;
  $featured = isset($_POST['featured_image_url']) ? esc_url_raw(wp_unslash($_POST['featured_image_url'])) : '';

  if ($title === '' && $content === '') {
    wp_send_json(array('ok' => false, 'error' => 'Nothing to publish (no title or content).'), 400);
  }

  $arr = array(
    'post_title'   => $title,
    'post_content' => $content,
    'post_status'  => $status,
    'post_type'    => 'post',
    'post_author'  => ahm_pub_admin_author(),
  );
  if ($excerpt !== '') $arr['post_excerpt'] = $excerpt;
  if ($slug !== '')    $arr['post_name']    = $slug;

  if ($post_id && get_post($post_id)) {
    $arr['ID'] = $post_id;
    $res = wp_update_post($arr, true);
  } else {
    $res = wp_insert_post($arr, true);
    $post_id = is_wp_error($res) ? 0 : intval($res);
  }
  if (is_wp_error($res)) {
    wp_send_json(array('ok' => false, 'error' => $res->get_error_message()), 500);
  }

  if ($featured !== '') {
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $media_id = media_sideload_image($featured, $post_id, $title, 'id');
    if (!is_wp_error($media_id)) set_post_thumbnail($post_id, $media_id);
  }

  // SEO meta title/description for common SEO plugins (Yoast, Rank Math).
  $meta_title = isset($_POST['meta_title']) ? sanitize_text_field(wp_unslash($_POST['meta_title'])) : '';
  $meta_desc  = isset($_POST['meta_desc'])  ? sanitize_textarea_field(wp_unslash($_POST['meta_desc'])) : '';
  if ($meta_title !== '') { update_post_meta($post_id, '_yoast_wpseo_title', $meta_title); update_post_meta($post_id, 'rank_math_title', $meta_title); }
  if ($meta_desc !== '')  { update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_desc); update_post_meta($post_id, 'rank_math_description', $meta_desc); }

  wp_send_json(array(
    'ok'        => true,
    'post_id'   => $post_id,
    'status'    => get_post_status($post_id),
    'link'      => get_permalink($post_id),
    'edit_link' => admin_url('post.php?post=' . $post_id . '&action=edit'),
    'slug'      => get_post_field('post_name', $post_id),
  ));
}
